module.exports = {
  content: [
    "./**/*.{html,php,js}",
    "./resources/views/**/*.blade.php"
  ],
  theme: { extend: {} },
  plugins: []
};